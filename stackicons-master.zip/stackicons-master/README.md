Stackicons
==========

Icon font and Sass-based construction kit for Stackicons-Social, which supports multiple button shapes and a unique "multi-color" option in CSS for over 60 social brands. 

For more information visit <http://stackicons.com>
